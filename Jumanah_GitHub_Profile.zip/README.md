<p align="center">
  <img src="./assets/header.svg" width="100%" alt="Jumanah Almohaimeed — Backend Engineer and Product Builder. Turning real workflows into dependable software." />
</p>

<p align="center">
  <a href="https://www.linkedin.com/in/jumanah-almohaimeed-40149a327">LinkedIn</a>
  &nbsp; · &nbsp;
  <a href="https://github.com/juumanah/masar-workflow-api">Masar Workflow API</a>
  &nbsp; · &nbsp;
  <a href="https://github.com/juumanah/Qawaed">Qawaed</a>
</p>

### Hi, I'm Jumanah.

I'm a software engineering graduate focused on **backend development, API design, and product engineering**.

Working in SaaS customer success and operations taught me to notice where work gets stuck: missing information, unclear ownership, and handoffs that depend on someone remembering to follow up. Building software is how I turn those observations into something useful.

I enjoy the questions behind an endpoint: **Who can access this? What can change? What happens when two requests arrive together?**

---

### What I'm building

| Project | The problem I'm working on | Engineering focus |
| :--- | :--- | :--- |
| **[Masar Workflow API](https://github.com/juumanah/masar-workflow-api)** | Giving service requests a clear path from submission to approval or rejection. | Java · Spring Boot · PostgreSQL · Access control · Optimistic locking · Tests |
| **[Qawaed](https://github.com/juumanah/Qawaed)** | Making compliance submissions, reviews, and decisions traceable across organizations. | NestJS · TypeScript · Tenant isolation · Audit history · Background processing |
| **Takween — تكوين** | Helping people find teammates for projects and hackathons. A product I founded, built, and launched. | Next.js · Supabase · Product discovery · User feedback |

### My current focus

- Going deeper with **Java, Spring Boot, and PostgreSQL**.
- Designing APIs with clear permissions, validation, and failure behavior.
- Understanding transactions, concurrent updates, and tenant boundaries.
- Making behavior easier to trust through automated tests and CI.

### Tools I work with

<p>
  <img alt="Java" src="https://img.shields.io/badge/Java-182524?style=flat-square" />
  <img alt="Spring Boot" src="https://img.shields.io/badge/Spring_Boot-182524?style=flat-square&amp;logo=springboot&amp;logoColor=A4D8BA" />
  <img alt="PostgreSQL" src="https://img.shields.io/badge/PostgreSQL-182524?style=flat-square&amp;logo=postgresql&amp;logoColor=A4D8BA" />
  <img alt="TypeScript" src="https://img.shields.io/badge/TypeScript-182524?style=flat-square&amp;logo=typescript&amp;logoColor=A4D8BA" />
  <img alt="Docker" src="https://img.shields.io/badge/Docker-182524?style=flat-square&amp;logo=docker&amp;logoColor=A4D8BA" />
  <img alt="GitHub Actions" src="https://img.shields.io/badge/GitHub_Actions-182524?style=flat-square&amp;logo=githubactions&amp;logoColor=A4D8BA" />
</p>

**Backend:** Spring Security · Spring Data JPA · NestJS · ASP.NET Core MVC  
**Data:** PostgreSQL · SQL Server · Supabase · Flyway  
**Product & workflow:** Next.js · Git · Maven · Figma

### How I approach the work

Understand the workflow. Make the rules explicit. Build a small version. Test what could go wrong. Improve it with feedback.

I'm interested in **backend engineering and product engineering opportunities**, especially where software makes everyday operations easier to run.

**[Let's connect on LinkedIn →](https://www.linkedin.com/in/jumanah-almohaimeed-40149a327)**
