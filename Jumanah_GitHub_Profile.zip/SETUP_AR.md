# تركيب بروفايل جمانة

1. في GitHub أنشئي مستودعًا باسم `juumanah` تحت حساب `juumanah`، واختاري Public.
2. ارفعي `README.md` ومجلد `assets` داخل جذر المستودع؛ لا ترفعي المجلد الخارجي github-profile نفسه.
3. اعتمدي التغييرات في الفرع الرئيسي. يظهر README تلقائيًا في صفحة الحساب.
4. من Edit profile، ضعي الاسم `Jumanah Almohaimeed`، واستخدمي النبذة التالية:

Backend Engineer | Java & Spring Boot | APIs, workflows & automation | Building products from real operational problems.

5. أضيفي رابط لينكدإن إلى Social accounts.
6. ثبّتي Masar Workflow API وQawaed عبر Customize your pins.

المحتوى المهني بالإنجليزية، بتصميم أخضر داكن ونعناعي. البانر موجود محليًا داخل المستودع، والشارات فقط تُحمّل من shields.io. يوجد وصف بديل لكل صورة. لم تُضف إحصائيات متغيرة أو عدادات زيارات أو رقم هاتف.

مستودع تكوين خاص؛ لا تغيّري خصوصيته لتركيب هذا البروفايل. الوصف التعريفي في README كافٍ، ويمكن إضافة رابط المنتج العام بعد التأكد من الرابط الحالي.

ملف preview.html معاينة محلية تقريبية للتصميم، وليست لقطة من GitHub. لا يلزم رفعه أو رفع هذا الملف للمستودع.
